package mp3tag.controller;

import java.io.*;
import java.util.*;

import org.jaudiotagger.audio.mp3.MP3File;
import org.jaudiotagger.tag.*;
import org.jaudiotagger.tag.id3.AbstractID3v2Tag;

public class Defmain {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws IOException, TagException, Exception {

		File oldFile;
		File newFile;
		String oldPath = "E:\\803";
		String newPath = "E:\\个人自定";

		String pre = "0000";

		for (int i = 1; i < 979; i++) {
			int len = String.valueOf(i).length();
			if (len < 4) {
				//源文件名
				oldFile = new File(oldPath + "\\" + pre.substring(len) + i + ".mp3");
				//新文件名
				newFile = new File(newPath + "\\" + pre.substring(len) + i + ".mp3");
				
				oldFile.renameTo(newFile);
				
				System.out.print(oldFile.getAbsolutePath() + " | " + oldFile.exists() + " || ");
				System.out.println(newFile.getAbsolutePath() + " | " + newFile.exists());
			}
		}
	}

	// 获取 MP3 文件的 Tag 信息
	public static String ReadTags(String mp3_file) throws IOException, TagException, Exception {

		MP3File Mp3File = new MP3File(mp3_file);

		AbstractID3v2Tag tag = Mp3File.getID3v2Tag();

		// 歌曲名称
		String title = tag.getFirst(FieldKey.TITLE);
		// 艺术家
		// String artist = tag.getFirst(FieldKey.ARTIST);
		// 专辑
		// String author = tag.getFirst(FieldKey.ALBUM);

		// System.out.println(title);
		// System.out.println(artist);
		// System.out.println(author);

		return title;
	}

	// 按照文件名称排序
	public static void orderByName(String filePath) {

		List<File> files = Arrays.asList(new File(filePath).listFiles());

		Collections.sort(files, new Comparator<File>() {
			@Override
			public int compare(File o1, File o2) {
				if (o1.isDirectory() && o2.isFile())
					return -1;
				if (o1.isFile() && o2.isDirectory())
					return 1;
				return o1.getName().compareTo(o2.getName());
			}
		});

		int i = 1;
		String pre = "0000";
		for (File f : files) {
			int len = String.valueOf(i).length();

			String fileName = pre.substring(len) + i + ".mp3";

			System.out.print(filePath + "\\" + fileName);
			f.renameTo(new File(filePath + "\\" + fileName));

			// System.out.println(" | " + f.getName());
			i++;
		}
	}
}
