$(document).ready(function(){
	$("#table").bootstrapTable({
            dataType: "json",
            method: 'get',
            contentType: "application/x-www-form-urlencoded",
            cache: false,
            url:"http://localhost:8999/jsp/inc/data.json",
            columns:
//..............................................................
                [
                    {
                        field: 'mideaNum',
                        title: '数量',
                        valign:"middle",
                        align:"center"
                    },
                    {
                        field: 'mideaPercent',
                        title: '占比',
                        valign:"middle",
                        align:"center"
                    },
                    {
                        field: 'panasonicNum',
                        title: '数量',
                        valign:"middle",
                        align:"center"
                    },
                    {
                        field: 'panasonicPercent',
                        title: '占比',
                        valign:"middle",
                        align:"center"
                    }
                ]
            
        })
});